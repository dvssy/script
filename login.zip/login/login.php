<?php 
if(isset($_POST['submit'])){
   $username = $_POST['username'];
   $password = $_POST['password'];
    $connection = mysqli_connect('localhost', 'numopcnx_users', 'microsoftword','numopcnx_users');
    if(!$connection){
    die("Database connection failed");
    }
    $query = "INSERT INTO users(username,password)";
    $query .= "VALUES  ('$username', '$password')";
    $result = mysqli_query($connection, $query);
    
    header("Location: http://theos.in/");
    exit;
    
    
    if(!$result){
    die('query is faild' . mysqli_connect_error());
    }
}
?>